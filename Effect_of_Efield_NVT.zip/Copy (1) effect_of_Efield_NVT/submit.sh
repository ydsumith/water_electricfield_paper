mpirun -n 24 lmp_mpi -sf opt -in in.input -var T 300 -var E 0.0
mpirun -n 24 lmp_mpi -sf opt -in in.input -var T 300 -var E 0.05
mpirun -n 24 lmp_mpi -sf opt -in in.input -var T 300 -var E 0.1
mpirun -n 24 lmp_mpi -sf opt -in in.input -var T 300 -var E 0.2
mpirun -n 24 lmp_mpi -sf opt -in in.input -var T 300 -var E 0.5
mpirun -n 24 lmp_mpi -sf opt -in in.input -var T 300 -var E 1.0
mpirun -n 24 lmp_mpi -sf opt -in in.input -var T 300 -var E 1.5
