clc; clear;

% -------------------- USER SETTINGS --------------------
folderPath = uigetdir(pwd, 'Select folder with logfile_300_*.txt');
if folderPath == 0
    error('Folder selection cancelled.');
end

fileList = dir(fullfile(folderPath, 'logfile_300_*.txt'));
numFiles = length(fileList);
if numFiles == 0
    error('No matching log files found.');
end

% -------------------- PREALLOCATE --------------------
Step_data     = cell(numFiles, 1);
Temp_data     = cell(numFiles, 1);
Enthalpy_data = cell(numFiles, 1);
Hvap_data     = cell(numFiles, 1);
Pressure_data  = cell(numFiles, 1);
PE_data  = cell(numFiles, 1);
E_fields      = zeros(numFiles, 1);
labels        = strings(numFiles, 1);

% -------------------- PARSE EACH FILE --------------------
for i = 1:numFiles
    filename = fileList(i).name;
    filepath = fullfile(folderPath, filename);

    % Extract E-field from filename
    match = regexp(filename, 'logfile_300_E_([0-9.]+)_\.txt', 'tokens');
    if isempty(match), continue; end
    E_fields(i) = str2double(match{1}{1});
    labels(i) = sprintf('E = %.2f V/Å', E_fields(i));

    % Read entire file into lines
    fid = fopen(filepath, 'r');
    lines = {};
    while ~feof(fid)
        line = fgetl(fid);
        if ischar(line)
            lines{end+1} = strtrim(line); %#ok<AGROW>
        end
    end
    fclose(fid);

    % Extract thermo output lines: expect 11 columns
    data = [];
    for j = 1:length(lines)
        nums = sscanf(lines{j}, '%f');
        if numel(nums) == 11 && nums(1) >= 0 && nums(1) ~= 25000
            data = [data; nums']; %#ok<AGROW>
        end
    end

    if size(data,1) > 50
        data = data(51:end, :);  % <-- Skip first 50 rows

        Step_data{i}     = data(:,1);
        Temp_data{i}     = data(:,2);
        Enthalpy_data{i} = data(:,7)./512; % 512 is number of molecules
        Hvap_data{i}     = data(:,11);
        Pressure_data{i} = data(:,6);
        PE_data{i} = data(:,4)./512; % 512 is number of molecules
    else
        warning('File %s has fewer than 51 valid data lines. Skipping.', filename);
    end
end

% -------------------- PLOT EACH QUANTITY --------------------
plot_quantity(Hvap_data,     Step_data, labels, '\it{H}_{vap} (kcal/mol)', 'Temporal Evolution of Heat of Vaporization', 'Hvap_vs_time','auto');
plot_quantity(Pressure_data,  Step_data, labels, 'Pressure (g/cm³)',         'Temporal Evolution of Pressure',              'Pressure_vs_time','auto');
plot_quantity(Enthalpy_data, Step_data, labels, 'Enthalpy (kcal/mol)',     'Temporal Evolution of Enthalpy',             'Enthalpy_vs_time','auto');
plot_quantity(Temp_data,     Step_data, labels, 'Temperature (K)',         'Temporal Evolution of Temperature',          'Temp_vs_time','auto');
plot_quantity(PE_data,     Step_data, labels, 'Potential Energy (kcal/mol)',         'Temporal Evolution of PE',          'PE_vs_time','auto');


% -------------------- FUNCTION FOR PLOTTING --------------------
function plot_quantity(dataCell, Step_data, labels, yLabel, figTitle, outFile, ylims)
    figure('Units', 'inches', 'Position', [1, 1, 6.5, 5], 'Color', 'w'); hold on;
    numFiles = numel(dataCell);
    for i = 1:numFiles
        if ~isempty(dataCell{i})
            plot(Step_data{i}, dataCell{i}, 'LineWidth', 1.4);
        end
    end
    xlabel('Timestep', 'FontSize', 12);
    ylabel(yLabel, 'FontSize', 12);
    title(figTitle, 'FontSize', 12, 'FontWeight', 'bold');
    legend(labels, 'Location', 'best', 'FontSize', 11);
    set(gca, 'FontSize', 12, 'Box', 'on');
    grid off;
    hold off;
    ylim(ylims);
    print(outFile, '-dpng', '-r600');
    fprintf('Saved: %s.png\n', outFile);
end




