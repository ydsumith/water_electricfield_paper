clc; clear;

% -------------------- USER SETTINGS --------------------
folderPath = uigetdir(pwd, 'Select folder with logfile_*.txt');
if folderPath == 0
    error('Folder selection cancelled.');
end

fileList = dir(fullfile(folderPath, 'logfile_*_E_*.txt'));
numFiles = length(fileList);
if numFiles == 0
    error('No matching log files found.');
end

% -------------------- PREALLOCATE --------------------
Step_data     = cell(numFiles, 1);
Temp_data     = cell(numFiles, 1);
Enthalpy_data = cell(numFiles, 1);
Hvap_data     = cell(numFiles, 1);
Pressure_data = cell(numFiles, 1);
PE_data       = cell(numFiles, 1);
dens_data     = cell(numFiles, 1);
vol_data      = cell(numFiles, 1);

avg_Hvap     = zeros(numFiles, 1);
avg_Pressure = zeros(numFiles, 1);
avg_Enthalpy = zeros(numFiles, 1);
avg_Temp     = zeros(numFiles, 1);
avg_PE       = zeros(numFiles, 1);
avg_dens     = zeros(numFiles, 1);
avg_vol      = zeros(numFiles, 1);

Temperatures = zeros(numFiles, 1);
E_fields     = zeros(numFiles, 1);
labels       = strings(numFiles, 1);

Tref = [235.5, 248, 260.5, 273, 285.5, 298, 310.5, 323, 335.5, 348, 360.5, 373, 400];
Cvib = [-0.2247	-0.1894	-0.1559	-0.1241	-0.0938	-0.0651	-0.0378	-0.0118	0.013	0.0365	0.059	0.0804	0.1235];
Cni = [-0.0001	-0.0003	-0.0007	-0.0014	-0.0027	-0.0048	-0.0079	-0.0125	-0.019	-0.0276	-0.0387	-0.0527	-0.094];
Cpol = [-0.82 -0.82 -0.82 -0.82 -0.82 -0.823 -0.82 -0.82 -0.82 -0.82 -0.82 -0.82 -0.82];

% -------------------- PARSE EACH FILE --------------------
for i = 1:numFiles
    filename = fileList(i).name;
    filepath = fullfile(folderPath, filename);

    % Extract temperature and E-field from filename
    match = regexp(filename, 'logfile_([0-9.]+)_E_([0-9.]+)_', 'tokens');

    if isempty(match), continue; end

    temp_val = str2double(match{1}{1});
    efield_val = str2double(match{1}{2});
    Temperatures(i) = temp_val;
    E_fields(i) = efield_val;
    labels(i) = sprintf('T = %d K, E = %.2f V/Å', temp_val, efield_val);

    % Read entire file
    fid = fopen(filepath, 'r');
    lines = {};
    while ~feof(fid)
        line = fgetl(fid);
        if ischar(line)
            lines{end+1} = strtrim(line); %#ok<AGROW>
        end
    end
    fclose(fid);

    % Extract thermo output lines (expect 9 columns)
    data = [];
    for j = 1:length(lines)
        nums = sscanf(lines{j}, '%f');
        if numel(nums) == 9 && nums(1) >= 0 && nums(1) ~= 25000
            data = [data; nums']; %#ok<AGROW>
        end
    end

    if size(data,1) > 5
        data = data(6:end, :);  % <-- Skip first 5 rows
        N = size(data,1);
        last_half = round(N/2)+1 : N;

        % step temp etotal pe ke press enthalpy density vol
        Step_data{i}     = data(:,1);
        Temp_data{i}     = data(:,2);
        Enthalpy_data{i} = data(:,7);
        Pressure_data{i} = data(:,6);
        PE_data{i}       = data(:,4);
        dens_data{i}     = data(:,8);
        vol_data{i}      = data(:,9);

        % Averages using last 50% of time series
        avg_Pressure(i) = mean(data(last_half,6));
        avg_Enthalpy(i) = mean(data(last_half,7));
        avg_Temp(i)     = mean(data(last_half,2));
        avg_PE(i)       = mean(data(last_half,4));
        avg_dens(i)     = mean(data(last_half,8));
        avg_vol(i)      = mean(data(last_half,9));

        % Apply temperature-dependent Hvap correction
        Gas_Const = 0.0019872065;     % kcal/mol·K
        press_Conv = 0.145839756e-4;  % kcal/mol·Å³

        % Find index of closest temperature in Tref
        [~, tidx] = min(abs(Tref - temp_val));
        % Use corresponding corrections from Cvib, Cni, and Cpol
        cvib_val = Cvib(tidx);
        cni_val  = Cni(tidx);
        cpol_val = Cpol(tidx);

        avg_Hvap(i) = -avg_PE(i) + Gas_Const*temp_val - press_Conv*avg_vol(i) + cvib_val + cni_val + cpol_val;
    else
        warning('File %s has fewer than 5 valid data lines. Skipping.', filename);
    end
end

% -------------------- DISPLAY AVERAGE RESULTS --------------------
fprintf('\n%-12s %-12s %-10s %-10s %-12s %-10s %-10s %-10s\n', ...
    'Temp (K)', 'E-field (V/Å)', 'Hvap', 'Pressure', 'Enthalpy', 'Temp', 'PE', 'Density');

for i = 1:numFiles
    fprintf('%-12.2f %-12.2f %-10.4f %-10.2f %-12.4f %-10.2f %-10.4f %-10.4f\n', ...
        Temperatures(i), E_fields(i), avg_Hvap(i), avg_Pressure(i), ...
        avg_Enthalpy(i), avg_Temp(i), avg_PE(i), avg_dens(i));
end

