% -------------------- SETTINGS --------------------
clc; clear;

% Prompt user to select the folder
folderPath = uigetdir(pwd, 'Select folder containing .data files');
if folderPath == 0
    error('Folder selection cancelled.');
end

% Find all matching files
fileList = dir(fullfile(folderPath, 'output_300_*.data'));
numFiles = length(fileList);
if numFiles == 0
    error('No matching .data files found.');
end

% Loop through each file
for i = 1:numFiles
    filename = fileList(i).name;
    datafile = fullfile(folderPath, filename);

    theta_bins = 180;
    phi_bins = 360;

    % Extract electric field value from filename
    efield_match = regexp(filename, 'output_300_([0-9.]+)\.data', 'tokens');

    if ~isempty(efield_match)
        efield_val = str2double(efield_match{1}{1});
        efield_str = sprintf(' (E = %.2f V/Å)', efield_val);
        efield_tag = strrep(sprintf('%.2f', efield_val), '.', '_');
    else
        efield_str = '';
        efield_tag = sprintf('file_%d', i);
    end

    % -------------------- READ LAMMPS DATA FILE --------------------
    fid = fopen(datafile);
    if fid == -1
        error('Could not open %s', datafile);
    end

    x_bounds = []; y_bounds = []; z_bounds = [];
    line = '';
    while ischar(line)
        line = fgetl(fid);
        if contains(line, 'xlo') && contains(line, 'xhi')
            x_bounds = sscanf(line, '%f %f');
        elseif contains(line, 'ylo') && contains(line, 'yhi')
            y_bounds = sscanf(line, '%f %f');
        elseif contains(line, 'zlo') && contains(line, 'zhi')
            z_bounds = sscanf(line, '%f %f');
        elseif contains(line, 'Atoms')
            break;
        end
    end

    lx = x_bounds(2) - x_bounds(1);
    ly = y_bounds(2) - y_bounds(1);
    lz = z_bounds(2) - z_bounds(1);

    fgetl(fid);  % skip blank/comment line

    atoms = [];
    while true
        line = fgetl(fid);
        if ~ischar(line) || isempty(line) || startsWith(line, 'Velocities') || ...
           startsWith(line, 'Bonds') || startsWith(line, 'Masses') || ...
           startsWith(line, 'Angles')
            break;
        end
        vals = sscanf(line, '%f');
        if numel(vals) < 10
            continue;
        end

        x = vals(5) + vals(8) * lx;
        y = vals(6) + vals(9) * ly;
        z = vals(7) + vals(10) * lz;

        atoms = [atoms; vals(1:3)', x, y, z];  % id, mol, type, x y z
    end
    fclose(fid);

    % -------------------- ANGLE COMPUTATION --------------------
    mol_ids = atoms(:,2);
    mol_list = unique(mol_ids);
    hist2D = zeros(theta_bins, phi_bins);
    angle_data = [];

    for m = 1:length(mol_list)
        mol_id = mol_list(m);
        mol_atoms = atoms(mol_ids == mol_id, :);
        if size(mol_atoms,1) ~= 3
            continue;
        end

        O = mol_atoms(mol_atoms(:,3) == 1, :);
        H = mol_atoms(mol_atoms(:,3) ~= 1, :);
        if size(O,1) ~= 1 || size(H,1) ~= 2
            continue;
        end

        OH1 = H(1,4:6) - O(1,4:6);
        OH2 = H(2,4:6) - O(1,4:6);
        dipole = (OH1 + OH2) / 2;
        if norm(dipole) < 1e-10
            continue;
        end
        u = dipole / norm(dipole);

        theta = acosd(u(3));         % [0, 180]
        phi = atan2d(u(2), u(1));    % [-180, 180]
        if phi < 0, phi = phi + 360; end

        t_bin = min(floor(theta), theta_bins - 1) + 1;
        p_bin = min(floor(phi), phi_bins - 1) + 1;

        hist2D(t_bin, p_bin) = hist2D(t_bin, p_bin) + 1;
        angle_data = [angle_data; theta, phi];
    end

    % -------------------- SAVE CSV --------------------
    [theta_grid, phi_grid] = ndgrid(0:theta_bins-1, 0:phi_bins-1);
    out = [theta_grid(:), phi_grid(:), hist2D(:)];
    csvname = fullfile(folderPath, sprintf('2D_orientation_histogram_E_%s.csv', efield_tag));
    writematrix([["Theta_Degrees", "Phi_Degrees", "Count"]; num2cell(out)], csvname);

    % -------------------- SCATTER PLOT --------------------
    fig = figure('Units', 'inches', 'Position', [1, 1, 4, 2.5], 'Color', 'w');
    scatter(angle_data(:,2), angle_data(:,1), 5, 'filled');
    xlabel('\phi (Azimuthal Angle, °)', 'FontSize', 11);
    ylabel('\theta (Polar Angle, °)', 'FontSize', 11);
    title(['Dipole Orientation' efield_str], 'FontSize', 12, 'FontWeight', 'bold');

    xlim([0, 360]); ylim([0, 180]);
    set(gca, 'FontSize', 10, 'LineWidth', 1, 'Box', 'on', ...
        'XTick', 0:90:360, 'YTick', 0:30:180, 'TickDir', 'out');
    axis square;
    grid on;

    % -------------------- EXPORT FIGURE --------------------
    figname = fullfile(folderPath, sprintf('dipole_orientation_E_%s.png', efield_tag));
    print(fig, figname, '-dpng', '-r600');
    close(fig);

    fprintf('Done. Saved: %s and %s\n', figname, csvname);
end
